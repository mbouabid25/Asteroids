package animation.demo;

public class AnimationStub extends AnimationDemo {

    public int getWidth() {
        return 100;
    }

}
